#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-2.0-or-later
# SPDX-FileCopyrightText: 2023 Kent Gibson <warthog618@gmail.com>

"""Minimal example of watching for edges on multiple lines."""

from collections.abc import Iterable

import gpiod
from gpiod.edge_event import EdgeEvent
from gpiod.line import Edge


def edge_type_str(event: EdgeEvent) -> str:
    if event.event_type is event.Type.RISING_EDGE:
        return "Rising"
    if event.event_type is event.Type.FALLING_EDGE:
        return "Falling"
    return "Unknown"


def watch_multiple_line_values(chip_path: str, line_offsets: Iterable[int]) -> None:
    with gpiod.request_lines(
        chip_path,
        consumer="watch-multiple-line-values",
        config={line_offsets: gpiod.LineSettings(edge_detection=Edge.BOTH)},
    ) as request:
        while True:
            for event in request.read_edge_events():
                print(
                    f"offset: {event.line_offset}"
                    f"  type: {edge_type_str(event):<7}"
                    f"  event #{event.global_seqno}"
                    f"  line event #{event.line_seqno}"
                )


if __name__ == "__main__":
    try:
        watch_multiple_line_values("/dev/gpiochip0", [5, 3, 7])
    except OSError as ex:
        print(ex, "\nCustomise the example configuration to suit your situation")
